# ComfyUI wrapper nodes for IC-light

# UPDATE: 
moving my efforts into a more native implementation: https://github.com/kijai/ComfyUI-IC-Light

## unfinished and development stopped
Original repo: https://github.com/lllyasviel/IC-Light/

Models: https://huggingface.co/lllyasviel/ic-light/tree/main

models go into `ComfyUI/models/unet`

![image](https://github.com/kijai/ComfyUI-IC-Light-Wrapper/assets/40791699/9687a243-d7af-4b08-99e9-d260f1859584)


